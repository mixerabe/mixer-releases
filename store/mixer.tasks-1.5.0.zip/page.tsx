import { Card, openNew, Page, Section, useQuery, useToday, type MixerObject, type PageProps } from 'mixer';

/** The day a task is due, if it is. */
const dueOf = (t: MixerObject<'mixer.task'>) => t.fields.due ?? null;

/** Your tasks: what's due now, an inbox of what has no day, what comes later, and what was done lately. */
export default function TasksApp({ object }: PageProps<'mixer.tasks'>) {
  const open = useQuery({ type: 'mixer.task', where: { done: false }, sort: 'due' });
  const recentlyDone = useQuery({ type: 'mixer.task', where: { done: true }, sort: 'updated', desc: true, limit: 8 });
  const day = useToday();
  const now = open.filter((t) => dueOf(t) !== null && dueOf(t)! <= day);
  const inbox = open.filter((t) => dueOf(t) === null);
  const later = open.filter((t) => dueOf(t) !== null && dueOf(t)! > day);

  return (
    <Page
      object={object}
      actions={
        // A new task opens as its own page, made when you press Create there.
        <button type="button" className="mx-btn mx-btn-primary" data-new="mixer.task" onClick={() => openNew('mixer.task')}>
          New task
        </button>
      }
    >
      <Section title="Today" count={now.length} empty="Nothing due today.">
        {now.map((t) => (
          <Card key={t.id} id={t.id} />
        ))}
      </Section>
      <Section title="Inbox" count={inbox.length} empty="No tasks without a date.">
        {inbox.map((t) => (
          <Card key={t.id} id={t.id} />
        ))}
      </Section>
      <Section title="Upcoming" count={later.length} empty="Nothing scheduled.">
        {later.map((t) => (
          <Card key={t.id} id={t.id} />
        ))}
      </Section>
      {recentlyDone.length > 0 && (
        <Section title="Recently done" count={recentlyDone.length}>
          {recentlyDone.map((t) => (
            <Card key={t.id} id={t.id} />
          ))}
        </Section>
      )}
    </Page>
  );
}
