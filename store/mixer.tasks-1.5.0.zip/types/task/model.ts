import { defineModel } from 'mixer/model';
import { today } from 'mixer/dates';

// A task is overdue once its day has passed with it not done.
export default defineModel('mixer.task', {
  computed: { overdue: (t) => !t.fields.done && !!t.fields.due && t.fields.due < today() },
});
