// Ask as a workflow's step: one question to the user, with the answers it offers or in their own words, its run waiting
// in Needs you until they answer, which the step gives back.
import { defineProgram } from 'mixer/program';

export default defineProgram({
  step: {
    wants: (input) => [
      {
        ask: {
          question: String(input.question ?? ''),
          options: (Array.isArray(input.options) ? input.options : input.options ? [input.options] : []).map(String),
          ownWords: input.ownWords === true,
        },
      },
    ],
    returns: (_input, [got]) => ({ answer: got?.ask?.answer ?? null }),
  },
});
