// Notify as a workflow's step: a notification to the user, opening its run or a record the step gives it.
import { defineProgram } from 'mixer/program';

export default defineProgram({
  step: {
    wants: (input) => [{ notify: { text: String(input.text ?? ''), ...(typeof input.open === 'string' && input.open && { open: input.open }) } }],
    returns: (input) => ({ text: String(input.text ?? '') }),
  },
});
