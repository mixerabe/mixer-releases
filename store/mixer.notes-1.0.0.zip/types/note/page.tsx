import { Field, Page, type PageProps } from 'mixer';

export default function NotePage({ object }: PageProps<'mixer.note'>) {
  return (
    <Page object={object} shown={['body']}>
      <style>{`.mixer-note-body .mx-rte { min-height: 55vh; font-size: 15px; }`}</style>
      <div className="mixer-note-body">
        <Field object={object} name="body" label={false} />
      </div>
    </Page>
  );
}
