import { defineProgram } from 'mixer/program';

/**
 * What a web page says of itself, on its record: for each link saved or changed, its page's description and cover image,
 * where the record has none yet, and its title while the record is titled by its link. What the record has stays.
 */
export default defineProgram({
  wants: (record) => (typeof record.fields.url === 'string' && record.fields.url ? [{ page: record.fields.url }] : []),
  writes: (record, [got]) => {
    const page = got?.page;
    if (!page) return null;
    const fields: Record<string, unknown> = {};
    if (page.description && !record.fields.description) fields.description = page.description;
    if (page.image && !record.fields.cover) fields.cover = page.image;
    const untitled = !record.title.trim() || record.title === record.fields.url;
    return { fields, ...(untitled && page.title && page.title !== record.title ? { title: page.title } : {}) };
  },
});
