import { Card, CardFrame, useQuery, useToday, type CardProps } from 'mixer';

export default function TasksAppCard({ object, size }: CardProps<'mixer.tasks'>) {
  const day = useToday();
  const due = useQuery({ type: 'mixer.task', where: { done: false, due: { op: 'lte', value: day } }, sort: 'due' });
  return (
    <CardFrame object={object} size={size} meta={`${due.length} due today`}>
      {due.slice(0, size === 'expanded' ? 8 : 3).map((t) => (
        <Card key={t.id} id={t.id} />
      ))}
    </CardFrame>
  );
}
