import { CardFrame, RichText, update, useToday, type CardProps } from 'mixer';
import { formatDate } from 'mixer/dates';

export default function TaskCard({ object, size }: CardProps<'mixer.task'>) {
  const { done, due, details, overdue } = object.fields;
  // "Today" and "Tomorrow" are relative to the day: render again when it changes.
  useToday();
  return (
    <CardFrame
      object={object}
      size={size}
      icon={false}
      done={done}
      leading={
        <input
          type="checkbox"
          aria-label="Done"
          checked={done}
          onChange={(e) => update(object, { fields: { done: e.target.checked } })}
          style={{ accentColor: 'var(--mx-accent)' }}
        />
      }
      meta={due && <span style={{ color: overdue ? 'var(--mx-danger)' : undefined }}>{formatDate(due, 'relative')}</span>}
    >
      {size === 'expanded' && details && <RichText value={details} />}
    </CardFrame>
  );
}
