import { today } from 'mixer/dates';
import { defineModel } from 'mixer/model';

export default defineModel('mixer.task', {
  computed: {
    overdue: (task) => !task.fields.done && !!task.fields.due && task.fields.due < today(),
  },
});
