import { useState } from 'react';
import { Field, fillFromLink, notify, Page, Section, update, type PageProps } from 'mixer';
import { Cover } from './cover.tsx';

/** Loads the bookmark's page on the base for its title, description, and cover (you confirm it in Mixer first). */
function PreviewButton({ object, again }: { object: PageProps<'mixer.bookmark'>['object']; again: boolean }) {
  const [busy, setBusy] = useState(false);
  return (
    <button
      type="button"
      className={`mx-btn${again ? '' : ' mx-btn-primary'}`}
      disabled={busy}
      data-bookmark-preview=""
      onClick={async () => {
        setBusy(true);
        try {
          await fillFromLink(object, { description: 'description', image: 'cover', title: true }, { replace: again });
        } catch (err) {
          notify((err as Error).message);
        } finally {
          setBusy(false);
        }
      }}
    >
      {busy ? 'Loading the page…' : again ? 'Refresh preview' : 'Get preview'}
    </button>
  );
}

export default function BookmarkPage({ object }: PageProps<'mixer.bookmark'>) {
  const { url, cover, description, site, favorite } = object.fields;
  const previewed = !!(cover || description);
  return (
    <Page
      object={object}
      leading={
        <button
          type="button"
          className="mx-btn"
          aria-label={favorite ? 'Favorite' : 'Not a favorite'}
          aria-pressed={favorite}
          title={favorite ? 'Remove from favorites' : 'Add to favorites'}
          onClick={() => update(object, { fields: { favorite: !favorite } })}
          style={{ border: 0, fontSize: 20, padding: '0 4px', color: favorite ? 'var(--mx-warning)' : 'var(--mx-muted)' }}
        >
          {favorite ? '★' : '☆'}
        </button>
      }
      subtitle={
        <a href={url} target="_blank" rel="noreferrer" style={{ color: 'inherit' }}>
          {site ?? url}
        </a>
      }
      actions={
        <>
          <a className="mx-btn" href={url} target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
            Open
          </a>
          <PreviewButton object={object} again={previewed} />
        </>
      }
    >
      <Cover url={cover} style={{ width: '100%', maxHeight: 360, borderRadius: 'var(--mx-radius)', background: 'var(--mx-surface)', marginBottom: 'var(--mx-space-4)' }} />
      <Field object={object} name="url" label="Link" />
      <Field object={object} name="description" label="Description" />
      <Section title="Note">
        <Field object={object} name="note" label={false} />
      </Section>
    </Page>
  );
}
