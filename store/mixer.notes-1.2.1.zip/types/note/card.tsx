import { BodyExcerpt, CardFrame, Field, type CardProps } from 'mixer';

export default function NoteCard({ object, size }: CardProps<'mixer.note'>) {
  return <CardFrame object={object} size={size}>{size === 'expanded' ? <Field object={object} name="body" label={false} /> : <BodyExcerpt object={object} />}</CardFrame>;
}
