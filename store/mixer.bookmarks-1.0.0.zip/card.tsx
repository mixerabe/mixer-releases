import { Card, CardFrame, useQuery, type CardProps } from 'mixer';

export default function BookmarksAppCard({ object, size }: CardProps<'mixer.bookmarks'>) {
  const recent = useQuery({ type: 'mixer.bookmark', sort: 'created', desc: true, limit: size === 'expanded' ? 6 : 3 });
  return (
    <CardFrame object={object} size={size} meta={recent.length ? undefined : 'No bookmarks yet'}>
      {recent.map((b) => (
        <Card key={b.id} id={b.id} />
      ))}
    </CardFrame>
  );
}
