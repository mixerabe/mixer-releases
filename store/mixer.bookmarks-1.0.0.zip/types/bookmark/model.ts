import { defineModel } from 'mixer/model';

/** The host a web address names (lowercase, without a user or a port), or null. */
const hostOf = (url: string | null) => (url && /^https?:\/\/(?:[^/?#@\s]*@)?(\[[^\]/?#]*\]|[^/?#:\s]+)/i.exec(url)?.[1]?.toLowerCase()) || null;

export default defineModel('mixer.bookmark', {
  computed: {
    site: (bookmark) => hostOf(bookmark.fields.url)?.replace(/^www\./, '') ?? null,
  },
  rules: {
    webAddress: (bookmark) => (bookmark.fields.url && !hostOf(bookmark.fields.url) ? 'The link must be a web address, starting with https:// or http://' : null),
  },
});
