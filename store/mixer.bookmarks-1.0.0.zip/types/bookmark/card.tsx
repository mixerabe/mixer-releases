import { CardFrame, type CardProps } from 'mixer';
import { Cover, KIND_NAMES } from './cover.tsx';

export default function BookmarkCard({ object, size }: CardProps<'mixer.bookmark'>) {
  const { cover, description, kind, site, favorite } = object.fields;
  const meta = (
    <>
      {favorite && <span aria-label="Favorite">★</span>}
      {kind && KIND_NAMES[kind] && <span>{KIND_NAMES[kind]}</span>}
      {site && <span>{site}</span>}
    </>
  );
  if (size === 'compact')
    return (
      <CardFrame
        object={object}
        size={size}
        icon={false}
        leading={<Cover url={cover} style={{ width: 36, height: 24, borderRadius: 4 }} fallback={<span style={{ width: 36, textAlign: 'center' }}>🔖</span>} />}
        meta={meta}
      />
    );
  return (
    <CardFrame object={object} size={size} icon={!cover} meta={meta}>
      <Cover url={cover} style={{ width: '100%', aspectRatio: '16 / 9', borderRadius: 6, background: 'var(--mx-surface)' }} />
      {description && (
        <div style={{ color: 'var(--mx-muted)', fontSize: 'var(--mx-text-sm)', marginTop: 6, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
          {description}
        </div>
      )}
    </CardFrame>
  );
}
