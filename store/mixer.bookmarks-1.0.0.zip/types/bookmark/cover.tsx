import { useEffect, useState, type CSSProperties, type ReactNode } from 'react';
import { imageSrc } from 'mixer';

/**
 * A bookmark's cover as Mixer keeps it, or `fallback` while there's none: no cover, or one Mixer has no copy of (it keeps
 * the images it loads for a page's preview).
 */
export function Cover({ url, style, fallback = null }: { url: string | null; style?: CSSProperties; fallback?: ReactNode }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [url]);
  if (!url || failed) return <>{fallback}</>;
  return <img src={imageSrc(url)} alt="" draggable={false} onError={() => setFailed(true)} style={{ display: 'block', objectFit: 'cover', ...style }} />;
}

/** What a bookmark's kind is called, when it says more than "a link". */
export const KIND_NAMES: Record<string, string> = { article: 'Article', video: 'Video', image: 'Image', audio: 'Audio', document: 'Document' };
