import { create, defineAction, query } from 'mixer/action';
import { normalizeUrl } from './url.ts';

export default defineAction('mixer.save-bookmark', ({ url, title }) => {
  const link = normalizeUrl(url);
  if (!link) throw new Error(`“${url}” isn't a web address: a link starts with https:// or http://`);
  // The bookmark already kept of the page, as saved here or written exactly so elsewhere: the first, if there are several.
  const [kept] = query({ type: 'mixer.bookmark', where: { url: { op: 'in', value: [...new Set([link, url.trim()])] } }, sort: 'created', limit: 1 });
  if (kept) return kept.id;
  return create('mixer.bookmark', { title: title?.trim() || link, fields: { url: link } }).id;
});
