/** Query parameters that only say where a link was shared from or clicked: a link is the same page without them. */
const TRACKING = /^(utm_[a-z0-9_]+|fbclid|gclid|dclid|gbraid|wbraid|msclkid|yclid|igshid|mc_cid|mc_eid|_hsenc|_hsmi|mkt_tok)$/i;

const DEFAULT_PORT: Record<string, string> = { http: '80', https: '443' };

/**
 * A web address as Mixer keeps it, so the same page saved twice is one bookmark: its scheme and host in lowercase, without
 * the scheme's default port, with a path ("/" at least), and without empty parameters or those TRACKING names;
 * everything else as written (paths and other parameters may mean something in any case or order). Null when it isn't an
 * http or https address with a host.
 */
export function normalizeUrl(input: string): string | null {
  const m = /^\s*(https?):\/\/([^/?#\s]*)([^?#\s]*)(\?[^#\s]*)?(#\S*)?\s*$/i.exec(input);
  if (!m) return null;
  const scheme = m[1].toLowerCase();
  const authority = m[2];
  const at = authority.lastIndexOf('@');
  const user = at >= 0 ? authority.slice(0, at + 1) : '';
  const hostPort = /^(\[[^\]]*\]|[^:]*)(?::(\d*))?$/.exec(authority.slice(at + 1));
  if (!hostPort || !hostPort[1]) return null;
  const host = hostPort[1].toLowerCase();
  const port = hostPort[2] && hostPort[2] !== DEFAULT_PORT[scheme] ? `:${hostPort[2]}` : '';
  const path = m[3] || '/';
  const params = (m[4] ?? '?')
    .slice(1)
    .split('&')
    .filter((p) => p !== '' && !TRACKING.test(p.split('=')[0]));
  const query = params.length ? `?${params.join('&')}` : '';
  const fragment = m[5] && m[5] !== '#' ? m[5] : '';
  return `${scheme}://${user}${host}${port}${path}${query}${fragment}`;
}
