import { CardFrame, Field, type CardProps } from 'mixer';

/** Markdown as one line of plain text: mentions keep their titles, formatting goes. */
const plain = (md: string | null) =>
  (md ?? '')
    .replace(/!?\[([^\]]*)\]\([^)]*\)/g, '$1')
    .replace(/^[#>\-*\s]+/gm, '')
    .replace(/[*_`]/g, '')
    .replace(/\s+/g, ' ')
    .trim();

export default function NoteCard({ object, size }: CardProps<'mixer.note'>) {
  // A note a connection keeps may not have its body loaded: its beginning shows.
  const preview = plain(object.fields.body ?? object.sync?.excerpt.body ?? null);
  return (
    <CardFrame object={object} size={size}>
      {size === 'expanded' ? (
        <Field object={object} name="body" label={false} />
      ) : (
        preview && <div style={{ color: 'var(--mx-muted)', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{preview}</div>
      )}
    </CardFrame>
  );
}
