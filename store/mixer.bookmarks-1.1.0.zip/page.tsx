import { useState, type DragEvent, type ReactNode } from 'react';
import { Card, Empty, Page, saveLink, update, useQuery, useWindowState, type PageProps } from 'mixer';

/** Which bookmarks show: all of them, or the favorites. */
type Place = 'all' | 'favorites';

const KINDS: [string, string][] = [
  ['article', 'Articles'],
  ['video', 'Videos'],
  ['image', 'Images'],
  ['audio', 'Audio'],
  ['document', 'Documents'],
  ['link', 'Links'],
];

/** A link dropped on the app (from a browser, a note): its address. */
function droppedLink(e: DragEvent): string | null {
  const url = (e.dataTransfer.getData('text/uri-list').split('\n').find((l) => l.trim() && !l.startsWith('#')) ?? e.dataTransfer.getData('text/plain')).trim();
  return /^https?:\/\//i.test(url) ? url : null;
}

const folded = (s: string | null | undefined) => (s ?? '').normalize('NFC').toLowerCase();

/** How many times each key occurs, most first. */
function counts(keys: (string | null | undefined)[]): [string, number][] {
  const by = new Map<string, number>();
  for (const k of keys) if (k) by.set(k, (by.get(k) ?? 0) + 1);
  return [...by.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
}

function NavItem({ selected, onClick, count, children }: { selected: boolean; onClick: () => void; count?: number; children: ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={selected}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        width: '100%',
        border: 0,
        borderRadius: 6,
        padding: '4px 8px',
        background: selected ? 'var(--mx-accent-soft)' : 'transparent',
        color: selected ? 'var(--mx-accent)' : 'var(--mx-fg)',
        cursor: 'pointer',
        textAlign: 'left',
      }}
    >
      <span style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{children}</span>
      {count !== undefined && <span style={{ color: 'var(--mx-muted)', fontSize: 'var(--mx-text-sm)' }}>{count}</span>}
    </button>
  );
}

const navTitle = { margin: 'var(--mx-space-4) 8px var(--mx-space-1)', fontSize: 'var(--mx-text-xs)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.05em', color: 'var(--mx-muted)' } as const;

function Filter({ selected, onClick, children }: { selected: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button type="button" className="mx-btn mx-btn-small" aria-pressed={selected} onClick={onClick} style={selected ? { background: 'var(--mx-accent-soft)', color: 'var(--mx-accent)', borderColor: 'var(--mx-accent-soft)' } : undefined}>
      {children}
    </button>
  );
}

export default function BookmarksApp({ object }: PageProps<'mixer.bookmarks'>) {
  const { layout } = object.fields;
  const bookmarks = useQuery({ type: 'mixer.bookmark', sort: 'created', desc: true, limit: 1000 });
  const [place, setPlace] = useWindowState<Place>('place', 'all');
  const [kind, setKind] = useWindowState<string | null>('kind', null);
  const [site, setSite] = useWindowState<string | null>('site', null);
  const [search, setSearch] = useState('');

  const here: Place = place === 'favorites' ? 'favorites' : 'all';
  const placed = bookmarks.filter((b) => here === 'all' || b.fields.favorite);
  const words = folded(search.trim());
  const shown = placed.filter(
    (b) =>
      (!kind || b.fields.kind === kind) &&
      (!site || b.fields.site === site) &&
      (!words || [b.title, b.fields.description, b.fields.url].some((t) => folded(t).includes(words))),
  );
  const kinds = new Map(counts(placed.map((b) => b.fields.kind)));
  const sites = counts(placed.map((b) => b.fields.site)).slice(0, 12);
  const heading = here === 'all' ? 'All bookmarks' : 'Favorites';

  const go = (p: Place) => {
    setPlace(p);
    setKind(null);
    setSite(null);
  };
  const onDrop = (e: DragEvent) => {
    const url = droppedLink(e);
    if (!url) return;
    e.preventDefault();
    void saveLink({ url });
  };

  return (
    <Page
      object={object}
      width="wide"
      actions={
        <>
          <input className="mx-input" type="search" placeholder="Search" value={search} onChange={(e) => setSearch(e.target.value)} style={{ width: 200, border: '1px solid var(--mx-border)' }} />
          <Filter selected={layout === 'grid'} onClick={() => update(object, { fields: { layout: 'grid' } })}>
            Grid
          </Filter>
          <Filter selected={layout === 'list'} onClick={() => update(object, { fields: { layout: 'list' } })}>
            List
          </Filter>
          <button type="button" className="mx-btn mx-btn-primary" data-save-link="" onClick={() => void saveLink()}>
            Save Link…
          </button>
        </>
      }
    >
      <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: 'var(--mx-space-5)', alignItems: 'start' }} onDragOver={(e) => e.preventDefault()} onDrop={onDrop}>
        <nav aria-label="Bookmarks">
          <NavItem selected={here === 'all'} onClick={() => go('all')} count={bookmarks.length}>
            All bookmarks
          </NavItem>
          <NavItem selected={here === 'favorites'} onClick={() => go('favorites')} count={bookmarks.filter((b) => b.fields.favorite).length}>
            Favorites
          </NavItem>
          {sites.length > 0 && <div style={navTitle}>Sites</div>}
          {sites.map(([s, n]) => (
            <NavItem key={s} selected={site === s} onClick={() => setSite(site === s ? null : s)} count={n}>
              {s}
            </NavItem>
          ))}
        </nav>
        <main>
          <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'baseline', gap: 'var(--mx-space-2)', marginBottom: 'var(--mx-space-3)' }}>
            <h2 style={{ margin: 0, fontSize: 'var(--mx-text-lg)', flex: '1 1 auto' }}>
              {heading} <span style={{ color: 'var(--mx-muted)', fontWeight: 400, fontSize: 'var(--mx-text-md)' }}>{shown.length}</span>
            </h2>
            {kinds.size > 1 &&
              KINDS.filter(([k]) => kinds.has(k)).map(([k, name]) => (
                <Filter key={k} selected={kind === k} onClick={() => setKind(kind === k ? null : k)}>
                  {name} {kinds.get(k)}
                </Filter>
              ))}
          </div>
          {shown.length === 0 ? (
            <Empty>
              {bookmarks.length === 0
                ? 'No bookmarks yet. Save a link, or drop one here.'
                : placed.length === 0
                  ? 'Nothing here yet. Save a link, or drop one here.'
                  : 'No bookmarks match.'}
            </Empty>
          ) : layout === 'list' ? (
            <div style={{ display: 'grid', gap: 'var(--mx-space-2)' }}>
              {shown.map((b) => (
                <Card key={b.id} id={b.id} />
              ))}
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 'var(--mx-space-3)' }}>
              {shown.map((b) => (
                <Card key={b.id} id={b.id} size="expanded" />
              ))}
            </div>
          )}
        </main>
      </div>
    </Page>
  );
}
