import { Field, Page, Section, update, type PageProps } from 'mixer';

export default function TaskPage({ object }: PageProps<'mixer.task'>) {
  const { done, overdue } = object.fields;
  return (
    <Page
      object={object}
      done={done}
      leading={
        <input
          type="checkbox"
          aria-label="Done"
          checked={done}
          onChange={(e) => update(object, { fields: { done: e.target.checked } })}
          style={{ width: 20, height: 20, accentColor: 'var(--mx-accent)' }}
        />
      }
      subtitle={overdue && <span style={{ color: 'var(--mx-danger)' }}>Overdue</span>}
    >
      <Field object={object} name="due" label="Due" />
      <Section title="Details">
        <Field object={object} name="details" label={false} />
      </Section>
    </Page>
  );
}
