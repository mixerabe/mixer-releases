import { defineModel } from 'mixer/model';

/** The host a web address names (lowercase, without a user or a port), or null when it isn't one. */
const hostOf = (url: unknown): string | null => (typeof url === 'string' && /^https?:\/\/(?:[^/?#@\s]*@)?(\[[^\]/?#]*\]|[^/?#:\s]+)/i.exec(url)?.[1]?.toLowerCase()) || null;

export default defineModel('mixer.link', {
  computed: {
    site: (record) => hostOf(record.fields.url)?.replace(/^www\./, '') ?? null,
  },
  rules: {
    webAddress: (record) => (record.fields.url && !hostOf(record.fields.url) ? 'The link must be a web address, starting with https:// or http://' : null),
  },
});
