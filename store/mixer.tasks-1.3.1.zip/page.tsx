import { Card, openNew, Page, Section, useQuery, useToday, type PageProps, type RecordObject } from 'mixer';

/** The day something to do is due, if it is: a record taking the todo format's `due`. */
const dueOf = (r: RecordObject) => (r.fields as { due?: string | null }).due ?? null;

/** Everything to do, whatever it is (a task, a bill, a chore of the user's): every record taking the todo format. */
export default function TasksApp({ object }: PageProps<'mixer.tasks'>) {
  const open = useQuery({ format: 'todo', where: { done: false }, sort: 'due' });
  const recentlyDone = useQuery({ format: 'todo', where: { done: true }, sort: 'updated', desc: true, limit: 8 });
  const day = useToday();
  const now = open.filter((t) => dueOf(t) !== null && dueOf(t)! <= day);
  const inbox = open.filter((t) => dueOf(t) === null);
  const later = open.filter((t) => dueOf(t) !== null && dueOf(t)! > day);

  return (
    <Page
      object={object}
      actions={
        // A new task opens as its own page, made when you press Create there.
        <button type="button" className="mx-btn mx-btn-primary" data-new="mixer.task" onClick={() => openNew('mixer.task')}>
          New task
        </button>
      }
    >
      <Section title="Today" count={now.length} empty="Nothing due today.">
        {now.map((t) => (
          <Card key={t.id} id={t.id} />
        ))}
      </Section>
      <Section title="Inbox" count={inbox.length} empty="No tasks without a date.">
        {inbox.map((t) => (
          <Card key={t.id} id={t.id} />
        ))}
      </Section>
      <Section title="Upcoming" count={later.length} empty="Nothing scheduled.">
        {later.map((t) => (
          <Card key={t.id} id={t.id} />
        ))}
      </Section>
      {recentlyDone.length > 0 && (
        <Section title="Recently done" count={recentlyDone.length}>
          {recentlyDone.map((t) => (
            <Card key={t.id} id={t.id} />
          ))}
        </Section>
      )}
    </Page>
  );
}
