import { CardFrame, DoneBox, DueLine, RichText, type CardProps } from 'mixer';

export default function TaskCard({ object, size }: CardProps<'mixer.task'>) {
  const { done, details } = object.fields;
  return (
    <CardFrame object={object} size={size} icon={false} done={done} leading={<DoneBox object={object} size="card" />} meta={<DueLine object={object} size="card" />}>
      {size === 'expanded' && details && <RichText value={details} />}
    </CardFrame>
  );
}
