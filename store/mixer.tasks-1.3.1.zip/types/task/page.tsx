import { DoneBox, DueLine, Field, Page, Section, type PageProps } from 'mixer';

export default function TaskPage({ object }: PageProps<'mixer.task'>) {
  return (
    <Page object={object} done={object.fields.done} leading={<DoneBox object={object} />} subtitle={<DueLine object={object} />}>
      <Field object={object} name="due" label="Due" />
      <Section title="Details">
        <Field object={object} name="details" label={false} />
      </Section>
    </Page>
  );
}
