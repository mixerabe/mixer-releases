// Mixer's AI as a workflow's step: one question to a model, with the records the step gives it, answered in the fields
// the step asks for, or in words.
import { defineProgram } from 'mixer/program';

export default defineProgram({
  step: {
    wants: (input, answers) => [
      {
        ai: {
          prompt: String(input.prompt ?? ''),
          ...(typeof input.instructions === 'string' && input.instructions && { instructions: input.instructions }),
          ...(typeof input.model === 'string' && input.model && { model: input.model }),
          ...(input.web === true && { web: true }),
          context: Array.isArray(input.context) ? input.context.filter((id): id is string => typeof id === 'string') : [],
          ...(answers && { output: answers }),
        },
      },
    ],
    returns: (_input, [got], answers) => {
      const said = got?.ai;
      if (!said) return null;
      return answers ? said.output : { text: said.text };
    },
  },
});
